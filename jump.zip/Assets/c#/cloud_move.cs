using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cloud_move : MonoBehaviour
{

    float time_=0;
    public float time_lim= 1;
    int move = 1;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        time_ += Time.deltaTime;
        if(time_> time_lim)
        {
            time_=0;
            transform.position = new Vector3(transform.position.x + move, transform.position.y, transform.position.z);
        }
    }


    void OnCollisionEnter2D(Collision2D collision)
    {

        if (collision.gameObject.tag == "Left")
        {
            move = 1;
        }

        if (collision.gameObject.tag == "Right")
        {
            move = -1;
        }
    }


}
