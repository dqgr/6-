using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class cat_move : MonoBehaviour
{
    int is_jump = 0;
    public Rigidbody2D rb;
    public SpriteRenderer sr;
    public Animator anima;
    float jump_force = 500.0f;
    float walk_force = 100.0f;
    float max_speed = 2.0f;
    int up_force = 0;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

        int key = 0;
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            key = -1;
            sr.flipX = true;
        }

        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            key = 1;
            sr.flipX = false;

        }
        float speed = Mathf.Abs(rb.velocity.x);

        if (speed < max_speed)
        {
            rb.AddForce(transform.right * key * walk_force);
        }

        if (Input.GetKeyDown(KeyCode.Space) && is_jump < 2)
        {

            rb.AddForce(transform.up * jump_force);
            anima.SetTrigger("JumpTrigger");
            is_jump++;;

        }

       

    }
     void OnCollisionEnter2D(Collision2D collision)
     {
            is_jump = 0;

            if (collision.gameObject.tag == "flag")
            {
                Debug.Log("clear");
                SceneManager.LoadScene("clear");
            }

            if(collision.gameObject.tag == "Jump_Up")
            {
                rb.AddForce(transform.up * (jump_force + 200.0f));
            }

           
     }

    private void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.tag == "Coin")
        {
            Gamemanager.instance.Add_Score(100);
            Destroy(collision.gameObject);
        }
        if (collision.tag == "Big_Coin")
        {
            Gamemanager.instance.Add_Score(500);
            Destroy(collision.gameObject);
        }
    }
}
