using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Gamemanager : MonoBehaviour
{

    public static Gamemanager instance;
    public int score = 0;
    public GameObject Text_UI;

    private void Awake()
    {
        instance = this; 
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Text_UI.GetComponent<Text>().text="����: "+score.ToString("D1");
    }

    public void Add_Score(int coin)
    {
        score += coin;
    }
}
