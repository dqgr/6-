using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class camera_move : MonoBehaviour
{
    public GameObject cat;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 player_pos = cat.transform.position;
        transform.position= new Vector3(transform.position.x, player_pos.y, transform.position.z);
    }
}
